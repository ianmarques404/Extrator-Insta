from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, NamedStyle
from datetime import datetime
import extrair_chat
import devices
import extrair_conexoes
import metadados
import followers
import following
import util
import os

# FUNÇÃO PRINCIPAL
def criar_planilha(linhas: list, linhas_logs: list, linhas_seguidores:list, linhas_seguindo: list, linhas_devices: list, linhas_cadastro: dict, caminho: str) -> None:
    wb = Workbook()
    print("Escrevendo xlsx...")
    ws_chat = wb.active

    criar_planilha_chats(linhas, ws_chat)
    criar_planilha_logs(linhas_logs, wb)
    criar_planilha_seguidores(linhas_seguidores, wb)
    criar_planilha_seguindo(linhas_seguindo, wb)
    criar_planilha_devices(linhas_devices, wb)
    criar_planilha_metadados(linhas_cadastro, wb)

    # CAMINHO DE SAÍDA
    nome = linhas_cadastro['username']
    chars_para_remover = "\\/:*?\"<>|"
    remover_chars = str.maketrans("", "", chars_para_remover)
    pasta = os.path.dirname(caminho)
    destino = f'{pasta}/{nome.translate(remover_chars)}_instagram.xlsx'
    wb.save(destino)
    print("Escrita finalizada.")


def criar_planilha_chats(linhas: list, ws_chat):
    # PLANILHA DE CHATS
    ws_chat.title = 'Chats'

    # CABEÇALHO
    ws_chat['A1'] = 'ID_Conversa'
    ws_chat['B1'] = 'Participantes'
    ws_chat['C1'] = 'Fuso'
    ws_chat['D1'] = 'Data_Hora'
    ws_chat['E1'] = 'Autor'
    ws_chat['F1'] = 'Corpo_Msg'

    # ADICIONANDO OS CHATS
    escrever_dados(linhas, ws_chat)
    
    # Aplicando formatação de data/hora à coluna D
    aplicar_formatacao_data_hora(ws_chat, 'D', len(linhas))
        
    # FORMATAÇÃO DA PLANILHA DE CHATS
    formatar_celulas(linhas, ws_chat)
    

    # TAMANHO DAS CÉLULAS DAS PLANILHAS DE CHATS
    ws_chat.column_dimensions['A'].width = 22
    ws_chat.column_dimensions['B'].width = 28
    ws_chat.column_dimensions['C'].width = 9
    ws_chat.column_dimensions['D'].width = 30
    ws_chat.column_dimensions['E'].width = 20
    ws_chat.column_dimensions['F'].width = 85


def criar_planilha_logs(linhas_logs: list, wb) -> None:
    # PLANILHA DOS LOGS
    ws_logs = wb.create_sheet(title="Conexões")
    # CABEÇALHO
    ws_logs['A1'] = 'Data_Hora'
    ws_logs['B1'] = 'Fuso'
    ws_logs['C1'] = 'IP'

    # ESCREVENDO OS DADOS DOS IPS
    escrever_dados(linhas_logs, ws_logs)

    # FORMATAÇÃO DA PLANILHA DE LOGS
    formatar_celulas(linhas_logs, ws_logs)
    

    # TAMANHO DAS CÉLULAS DAS PLANILHAS DE Logs
    ws_logs.column_dimensions['A'].width = 22
    ws_logs.column_dimensions['B'].width = 9
    ws_logs.column_dimensions['C'].width = 38

def criar_planilha_seguidores(linhas_seguidores: list, wb) -> None:
    # PLANILHA DOS SEGUIDORES
    ws_seguidores = wb.create_sheet(title="Seguidores")
    # CABEÇALHO
    ws_seguidores['A1'] = 'Id'
    ws_seguidores['B1'] = 'Username'
    ws_seguidores['C1'] = 'Nome'
    ws_seguidores['D1'] = 'Data_Hora'

    # ESCREVENDO OS DADOS DOS SEGUIDORES
    escrever_dados(linhas_seguidores, ws_seguidores)

    # FORMATAÇÃO DA PLANILHA DE SEGUIDORES
    formatar_celulas(linhas_seguidores, ws_seguidores)
    

    # TAMANHO DAS CÉLULAS DAS PLANILHAS DE SEGUIDORES
    ws_seguidores.column_dimensions['A'].width = 15
    ws_seguidores.column_dimensions['B'].width = 30
    ws_seguidores.column_dimensions['C'].width = 35
    ws_seguidores.column_dimensions['D'].width = 22

def criar_planilha_seguindo(linhas_seguindo: list, wb) -> None:
    # PLANILHA DOS SEGUINDO
    ws_seguindo = wb.create_sheet(title="Seguindo")
    # CABEÇALHO
    ws_seguindo['A1'] = 'Id'
    ws_seguindo['B1'] = 'Username'
    ws_seguindo['C1'] = 'Nome'
    ws_seguindo['D1'] = 'Simetria'

    # ESCREVENDO OS DADOS DOS SEGUINDO
    escrever_dados(linhas_seguindo, ws_seguindo)

    # FORMATAÇÃO DA PLANILHA DE SEGUINDO
    formatar_celulas(linhas_seguindo, ws_seguindo)
    

    # TAMANHO DAS CÉLULAS DAS PLANILHAS DE SEGUINDO
    ws_seguindo.column_dimensions['A'].width = 15
    ws_seguindo.column_dimensions['B'].width = 30
    ws_seguindo.column_dimensions['C'].width = 35
    ws_seguindo.column_dimensions['D'].width = 22

def criar_planilha_devices(linhas_devices, wb) -> None:
    # PLANILHA DOS DISPOSITIVOS
    ws_devices = wb.create_sheet(title="Dispositivos")
    # CABEÇALHO
    ws_devices['A1'] = 'Tipo'
    ws_devices['B1'] = 'Id'
    ws_devices['C1'] = 'Active'
    ws_devices['D1'] = 'User'

    # ESCREVENDO OS DADOS DOS DISPOSITIVOS
    escrever_dados(linhas_devices, ws_devices)

    # FORMATAÇÃO DA PLANILHA DE DISPOSITIVOS
    formatar_celulas(linhas_devices, ws_devices)

    # TAMANHO DAS CÉLULAS DAS PLANILHAS DOS DISPOSITIVOS
    ws_devices.column_dimensions['A'].width = 10
    ws_devices.column_dimensions['B'].width = 38
    ws_devices.column_dimensions['C'].width = 10
    ws_devices.column_dimensions['D'].width = 28

#Função criar_planilha_metadados original(linhas ao invés de colunas)
#def criar_planilha_metadados(linhas_cadastro: dict, wb) -> None:
#    # PLANILHA DOS METADADOS
#    ws_metadados = wb.create_sheet(title="Conta")
#    for dado in linhas_cadastro.items():
#        try:
#            ws_metadados.append(dado)
#        except Exception as e:
#            ws_metadados.append(f"ERRO NA ESCRITA NO EXCEL. Mensagem: {e}")
#
#     CABEÇALHO
#    ws_metadados['A1'] = 'Campo'
#    ws_metadados['B1'] = 'Valor'
#
#    formatar_celulas(list(linhas_cadastro.values()), ws_metadados)
#
#    # TAMANHO DAS CÉLULAS DAS PLANILHAS DOS DISPOSITIVOS
#    ws_metadados.column_dimensions['A'].width = 20
#    ws_metadados.column_dimensions['B'].width = 44

# Modificada a função para facilitar o tratamento no Qlik, Colunas ao invés de linhas
def criar_planilha_metadados(linhas_cadastro: dict, wb) -> None:
    ws_metadados = wb.create_sheet(title="Conta")
    if not linhas_cadastro:
        return

    # Escreve os campos como colunas (linha 1)
    for col_idx, campo in enumerate(linhas_cadastro.keys(), start=1):
        ws_metadados.cell(row=1, column=col_idx, value=campo)

    # Escreve os valores na linha 2
    for col_idx, valor in enumerate(linhas_cadastro.values(), start=1):
        try:
            ws_metadados.cell(row=2, column=col_idx, value=valor)
        except Exception as e:
            ws_metadados.cell(row=2, column=col_idx, value=f"ERRO: {e}")

    # Ajusta largura das colunas
    for col_idx, campo in enumerate(linhas_cadastro.keys(), start=1):
        col_letter = chr(64 + col_idx) if col_idx <= 26 else 'Z'
        ws_metadados.column_dimensions[col_letter].width = 20



def escrever_dados(linhas: list, ws) -> None:
    # ESCREVER CADA ITEM DA LISTA EM UMA LINHA DO EXCEL
    for linha in linhas:
        try:
            ws.append(linha)
        except Exception as e:
            ws.append(f"ERRO DE ESCRITA NO EXCEL: \n Mensagem: {e}")
    
    # Adiciona a formatação de hiperlink se o conteúdo da célula for um link
    for row in ws.iter_rows(min_row=2, max_col=ws.max_column):
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith('=HYPERLINK'):
                cell.hyperlink = cell.value.split('"')[1]
                cell.font = Font(color="0000FF", underline="single")


# FORMATAÇÃO DAS CÉLULAS (EXCETO LARGURA)
def formatar_celulas(linhas: list, ws) -> None:
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center', vertical='bottom')
        cell.fill = PatternFill(start_color='E6E6FA', end_color='E6E6FA', fill_type='solid')

    for row in ws.iter_rows(min_row=2, max_row=len(linhas) + 1, min_col=1, max_col=4):
        for cell in row:
            cell.font = Font(bold=False)
            cell.alignment = Alignment(horizontal='left', vertical='bottom')

# FORMATAÇÃO DATA_HORA  
def aplicar_formatacao_data_hora(ws, coluna, num_linhas):
    # Criando um estilo de célula para data/hora
    date_time_style = NamedStyle(name="datetime_style", number_format="DD/MM/YYYY HH:MM:SS")
    # Aplicando o estilo de data/hora às células da coluna especificada
    col_idx = ord(coluna) - 64  # Converte a letra da coluna para índice numérico
    for row in ws.iter_rows(min_row=2, min_col=col_idx, max_col=col_idx, max_row=num_linhas + 1):
        for cell in row:
            # Verifica se o valor da célula pode ser convertido para uma data/hora
            try:
                if isinstance(cell.value, (str, datetime)):
                    # Converte a string para um objeto datetime, se necessário
                    if isinstance(cell.value, str):
                        cell.value = datetime.strptime(cell.value, "%d/%m/%Y %H:%M:%S")
                    cell.style = date_time_style
            except ValueError:
                continue


# FUNÇÕES PARA TESTE
def main(caminho: str) -> None:
    
    conteudo = util.ler_arquivo(caminho)
    conteudo = util.limpar_texto(conteudo)
    linhas = extrair_chat.extrair_dados(conteudo)
    linhas_logs = extrair_conexoes.extrair_ips(conteudo)
    linhas_devices = devices.extrair_devices(conteudo)
    linhas_cadastro = metadados.extrair_cadastro(conteudo)
    linhas_seguidores = followers.extrair_seguidores(conteudo)
    linhas_seguindo = following.extrair_seguindo(conteudo, [ids[0] for ids in linhas_seguidores])
    criar_planilha(linhas, linhas_logs, linhas_seguidores, linhas_seguindo, linhas_devices, linhas_cadastro, caminho)

if __name__ == '__main__':
    caminho: str = r"C:\Users\talles.tov\Downloads\4205.html"
    main(caminho)
