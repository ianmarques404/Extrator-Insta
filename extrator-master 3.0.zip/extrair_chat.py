# extrair_chat.py (The Final Version with Participant Bug Fixed)
from bs4 import BeautifulSoup
from util import tratar_data_hora
import re

def extrair_dados(conteudo: str) -> list:
    """
    This is the definitive script. It fixes the participant bug by
    processing each conversation thread individually.
    """
    print("Iniciando extração...")
    todas_as_linhas = []
    
    try:
        # Use BeautifulSoup to get the main content block as plain text
        soup = BeautifulSoup(conteudo, 'lxml')
        chat_container = soup.find('div', id='property-unified_messages')
        text_content = chat_container.get_text(separator=' ', strip=True) if chat_container else soup.get_text(separator=' ', strip=True)
        text_content = re.sub(r'\s+', ' ', text_content)

        # --- THE FIX: Split the content into threads FIRST ---
        # A thread is identified by the keyword "Thread" followed by its participants.
        # We split the document by this keyword to get a list of conversations.
        thread_chunks = re.split(r'Thread (?=.*?Current Participants)', text_content)

        if len(thread_chunks) < 2:
            print("[AVISO] Nenhum thread de conversa foi encontrado para dividir.")
            return []

        # Loop through each conversation chunk
        for chunk in thread_chunks[1:]:
            # --- Participant Extraction (from within the current chunk) ---
            participants_text = "Participantes não identificados"
            # Find all users listed between "Current Participants" and the first "Author"
            participants_match = re.search(r'Current Participants (.*?)(?= Author )', chunk)
            if participants_match:
                p_list = re.findall(r'([a-zA-Z0-9._]+\s*\(Instagram: \d+\))', participants_match.group(1))
                if p_list:
                    participants_text = ", ".join(list(dict.fromkeys(p_list)))

            # --- Message Extraction (from within the current chunk) ---
            pattern = re.compile(r"Author (.*?\(Instagram: \d+\)) Sent (.*?UTC) Body (.*?)(?= Author |$)")
            matches = pattern.finditer(chunk)

            for match in matches:
                autor, data_hora_str, corpo = match.groups()
                data_hora_tratada = tratar_data_hora(data_hora_str.strip())
                fuso = "UTC"
                
                # Append the message with the *correct* participants for this thread
                todas_as_linhas.append([participants_text, fuso, data_hora_tratada, autor.strip(), corpo.strip()])

    except Exception as e:
        print(f"[ERRO] Falha crítica durante a extração: {e}")

    if not todas_as_linhas:
        print("[AVISO] Nenhum chat foi extraído.")
    else:
        print(f"SUCESSO! Extração finalizada. {len(todas_as_linhas)} mensagens encontradas.")
        
    return todas_as_linhas