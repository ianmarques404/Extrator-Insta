from util import *

def extrair_devices(conteudo: str) -> list:
    #texto: str = limpar_texto(conteudo)
    lista_campos: list = obter_lista_campos(conteudo)
    inicio: str = ">Devices<"
    #fim: str = ">Following Definition<"
    fim: str = ">" + str(lista_campos[lista_campos.index('devices') + 1]).replace("_"," ").title() + " Definition<"
    devices_regiao: str = obter_regiao_interesse(conteudo, inicio, fim)
    posicoes: list = obter_posicoes(">Type<", devices_regiao)
    tabela_devices: list = obter_texto_dados(devices_regiao, posicoes)
    devices: list = obter_devices(tabela_devices)
    return devices

# FUNÇÃO AUXILIAR QUE EXTRAI OS CAMPOS DO TEXTO PRINCIPAL
def obter_devices(dados: list) -> list:
    linhas_devices: list = []
    for dado in dados:
        type: str = dado[dado.find('>Type<')+5:dado.find("</div>")]
        type = re.sub('<[\w \d\=\"\'\/]{1,}>','',type) if type is not None else "" 

        id: str = dado[dado.find(">Id<")+3:dado.find("</div>",dado.find(">Id<"))]
        id = re.sub('<[\w \d\=\"\'\/]{1,}>','',id) if id is not None else ""

        active: str = dado[dado.find(">Active<")+7:dado.find("</div>",dado.find(">Active<"))]
        active = re.sub('<[\w \d\=\"\'\/]{1,}>','',active) if active is not None else ""

        if dado.find(">User<") != -1:
            user: str = dado[dado.find(">User<")+5:dado.find("</div>", dado.find(">User<"))]
            user = re.sub('<[\w \d\=\"\'\/]{1,}>','',user) if user is not None else ""
        else:
            user: str = " - "
        linhas_devices.append([type, id, active, user])
    return linhas_devices


# FUNÇÕES PARA TESTE
def main(caminho):
    conteudo = ler_arquivo(caminho)
    conteudo = limpar_texto(conteudo)
    devices = extrair_devices(conteudo)
    print(devices)


if __name__ == '__main__':
    caminho: str = r"C:\Users\talles.tov\Downloads\2716.html"
    main(caminho)