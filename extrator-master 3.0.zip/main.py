from util import *
import extrair_chat
import extrair_conexoes
import devices
import metadados
import followers
import following


# FUNÇÃO DE LEITURA: SEPARADA POR QUE DEVE SER EXECUTADA PRIMEIRO.
"""def ler(origem: str) -> str:
    conteudo: str = ler_arquivo(origem)
    print("Lendo arquivo html...")
    conteudo = limpar_texto(conteudo)
    return conteudo"""


# FUNÇÃO ASSÍNCRONA QUE EXECUTA PARALELAMENTE TODAS OS PROCESSAMENTOS DE DADOS
def extrair_tudo(conteudo: str) -> tuple:
    try:
        lista_campos: list = obter_lista_campos(conteudo)
        try:
            chats = extrair_chat.extrair_dados(conteudo) if 'unified_messages' in lista_campos else ""
            print("Extraindo chats...")
        except:
            chats = ""
            print("Nenhum registro de mensagem encontrado. Cheque o material bruto.")
        try:
            logs = extrair_conexoes.extrair_ips(conteudo) if 'ip_addresses' in lista_campos else ""
            print("Extraindo logs...")
        except:
            logs = ""
            print("Nenhum registro de conexão encontrado. Cheque o material bruto.")
        try:
            dados_devices = devices.extrair_devices(conteudo) if 'devices' in lista_campos else ""
            print("Extraindo dispositivos...")
        except:
            dados_devices = ""
            print("Nenhum registro de dispositivo encontrado. Cheque o material bruto.")
        try:
            cadastro = metadados.extrair_cadastro(conteudo)
            print("Extraindo dados da conta...")
        except:
            cadastro = ""
            print("Nenhum dado da conta encontrado. Cheque o material bruto.")
        try:
            seguidores = followers.extrair_seguidores(conteudo) if 'followers' in lista_campos else ""
            print("Extraindo seguidores...")
        except:
            seguidores = ""
            print("Nenhum registro de seguidores encontrado. Cheque o material bruto.")
        try:
            seguindo = following.extrair_seguindo(conteudo, [ids[0] for ids in seguidores]) if 'following' in lista_campos else ""
            print("Extraindo seguindo...")
        except:
            seguindo = ""
            print("Nenhum registro de seguindo encontrado. Cheque o material bruto.")

        # AGUARDA TODAS AS TAREFAS DE PROCESSAMENTO PARALELO
        #await asyncio.gather(tarefa_chats, tarefa_cadastro, tarefa_logs)
        print("Processamento finalizado.")
        # RESULTADO DAS TAREFAS EM PARALELO
        #chats = tarefa_chats
        #logs = tarefa_logs
        #dados_devices = tarefa_devices
        #dados_cadastro = tarefa_cadastro

        return chats, logs, dados_devices, cadastro, seguidores, seguindo
        


    except Exception as e:
        msg_error = f"Erro no processamento dos dados: {e}"
        print(msg_error)
        return None


def main(caminho: str):
    conteudo: str = limpar_texto(ler_arquivo(caminho))
    chats, logs, dados_devices, dados_cadastro, seguidores, seguindo = extrair_tudo(conteudo)
    
    for dado in dados_cadastro.values():
        print(dado)
    
    for dado in chats[-100:]:
        print(dado)
    
    for seguidor in seguidores[0:100]:
        print(seguidor)
    
    for s in seguindo[0:100]:
        print(s)

    lista_campos = obter_lista_campos(conteudo)
    print(lista_campos)

if __name__ == '__main__':
    caminho: str = r"C:\Users\talles.tov\Downloads\2716.html"
    main(caminho)