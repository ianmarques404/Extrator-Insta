from util import *
import followers

def extrair_seguindo(conteudo: str, ids_seguidores: list) -> list:
    lista_campos: list = obter_lista_campos(conteudo)
    inicio: str = '<div class="t i">Following<div class="m">'
    #fim: str = ">Followers Definition<"
    fim: str = ">" + str(lista_campos[lista_campos.index('following') + 1]).replace("_",
                                                                                       " ").title() + " Definition<"
    seguindo_regiao: str = obter_regiao_interesse(conteudo, inicio, fim)[26:]
    tabela_seguindo: list = seguindo_regiao.split("</div>")
    seguindo: list = obter_seguindo(tabela_seguindo, ids_seguidores)
    return seguindo

# FUNÇÃO AUXILIAR QUE EXTRAI OS CAMPOS DO TEXTO PRINCIPAL
def obter_seguindo(dados: list, ids_seguidores: list) -> list:
    linhas_seguidores: list = []
    for dado in dados:
        seguindo = re.sub('<[\w \d\=\"\'\/]{1,}>','',dado)  
        try:
            username_seguindo = seguindo.split(" ")[0] if seguindo is not None else ""
        except:
            username_seguindo = ""
        try:
            id_seguindo = seguindo.split(" ")[1].strip("()") if seguindo is not None else ""
        except:
            id_seguindo = ""
        try:
            nome_seguidor = seguindo[seguindo.find("["):-1].strip("[]") if seguindo is not None else ""
        except:
            nome_seguidor = ""
        simetrico = "simétrico" if id_seguindo in ids_seguidores else "assimétrico"
        linhas_seguidores.append([id_seguindo,username_seguindo,nome_seguidor, simetrico])
    return linhas_seguidores


# FUNÇÕES PARA TESTE
def main(caminho):
    conteudo = ler_arquivo(caminho)
    conteudo = limpar_texto(conteudo)
    seguidores = followers.extrair_seguidores(conteudo)
    ids_seguidores = [ids[0] for ids in seguidores]
    seguindos = extrair_seguindo(conteudo, ids_seguidores)
    for seguindo in seguindos[0:100]:
        print(seguindo)
    #print(seguidores)


if __name__ == '__main__':
    caminho: str = r"C:\Users\talle\OneDrive\Documentos\Ferramentas\arquivos para teste\records.html"
    main(caminho)