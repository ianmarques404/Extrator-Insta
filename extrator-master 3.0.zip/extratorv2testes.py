# extratorv2testes.py (or extrator_v2.py)

import os
import zipfile
import pandas as pd
import re
import traceback
from bs4 import BeautifulSoup
from util import limpar_texto
from main import extrair_tudo

BASE_DIR = r"C:\CIAF\Extrator_Instagram\DADOS"

def sanitize_filename(filename):
    """Removes illegal characters from a filename and shortens it."""
    if "https://" in filename:
        filename = filename.rstrip('/').split('/')[-1]
    return re.sub(r'[\\/*?:"<>|]', "", filename)[:100]

def salvar_csv(dados, colunas, caminho_csv):
    if not dados:
        return
    df = pd.DataFrame(dados, columns=colunas)
    if os.path.exists(caminho_csv):
        df.to_csv(caminho_csv, mode='a', index=False, header=False, encoding='utf-8-sig')
    else:
        df.to_csv(caminho_csv, index=False, encoding='utf-8-sig')

def extrair_account_id(html_content):
    """Finds the Account Identifier using a fast and reliable regex search."""
    match = re.search(r'Account Identifier</div><div class="m"><div>([^<]+)</div>', html_content)
    if match:
        return match.group(1).strip()
    match = re.search(r'Account Identifier.*?<div>([^<]+)<', html_content)
    if match:
        return match.group(1).strip()
    return "desconhecido"

def extrair_generated_time(html_content):
    """Extracts the 'Generated' timestamp from the HTML."""
    match = re.search(r'Generated<div class="m"><div>([^<]+UTC)', html_content)
    if match:
        return match.group(1).strip()
    return "Não encontrado"

def extrair_date_range(html_content):
    """Extracts the 'Date Range' from the HTML."""
    match = re.search(r'Date Range<div class="m"><div>([^<]+ to [^<]+)', html_content)
    if match:
        return match.group(1).strip()
    return "Não encontrado"


# In extratorv2testes.py

def processar_zips():
    for file in os.listdir(BASE_DIR):
        if file.lower().endswith('.zip'):
            zip_path = os.path.join(BASE_DIR, file)
            try:
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    # Find all relevant HTML files, prioritizing preservation files
                    html_files_to_process = [
                        n for n in zip_ref.namelist()
                        if ('preservation' in n.lower() or 'records.html' in n.lower()) and n.lower().endswith('.html')
                    ]

                    if not html_files_to_process:
                        print(f"[AVISO] Nenhum arquivo HTML relevante em {file}")
                        continue

                    # --- Initialize lists to hold data from all files ---
                    all_chats, all_logs, all_devices, all_followers, all_seguindo = [], [], [], [], []
                    preservation_data_list = []
                    account_id = None
                    pasta_saida = None

                    # --- Loop through each HTML file found ---
                    for html_filename in html_files_to_process:
                        print(f"\n[INFO] Processando arquivo interno: {html_filename}")
                        with zip_ref.open(html_filename) as f:
                            conteudo = f.read().decode('utf-8')
                            conteudo = limpar_texto(conteudo)

                        # Determine account ID and output path ONCE
                        if not account_id:
                            account_id = extrair_account_id(conteudo)
                            pasta_saida = os.path.join(BASE_DIR, sanitize_filename(account_id))
                            os.makedirs(pasta_saida, exist_ok=True)
                            print(f"[INFO] Processando ZIP: {zip_path} → conta {sanitize_filename(account_id)}")
                            # Extract all relevant files from the zip once
                            print(f"[INFO] Extraindo arquivos para {pasta_saida}")
                            for member in zip_ref.infolist():
                                if member.filename.lower().endswith('.html') or member.filename.lower().startswith('linked_media/'):
                                    zip_ref.extract(member, pasta_saida)

                        # --- Logic for PRESERVATION.CSV ---
                        if 'preservation' in html_filename.lower():
                            generated_time = extrair_generated_time(conteudo)
                            date_range = extrair_date_range(conteudo)
                            preservation_data_list.append({
                                'Arquivo de Origem': html_filename,
                                'Data de Geração': generated_time,
                                'Intervalo de Datas': date_range
                            })

                        # --- Extract data from the current file ---
                        chats, logs, devices, metadados_info, seguidores, seguindo = extrair_tudo(conteudo)

                        # --- Append data to the main lists ---
                        all_chats.extend(chats)
                        all_logs.extend(logs)
                        all_devices.extend(devices)
                        all_followers.extend(seguidores)
                        all_seguindo.extend(seguindo)
                    
                    # --- Save all consolidated data AFTER the loop ---
                    print("\n[INFO] Salvando arquivos CSV consolidados...")
                    
                    if preservation_data_list:
                        df_preservation = pd.DataFrame(preservation_data_list)
                        preservation_csv_path = os.path.join(pasta_saida, 'PRESERVATION.CSV')
                        df_preservation.to_csv(preservation_csv_path, index=False, encoding='utf-8-sig')
                        print(f"[OK] PRESERVATION.CSV salvo com {len(preservation_data_list)} entradas.")

                    salvar_csv(all_chats, ['Participantes', 'Fuso', 'Data_Hora', 'Autor', 'Corpo_Msg'], os.path.join(pasta_saida, 'chats.csv'))
                    salvar_csv(all_logs, ['Data_Hora', 'Fuso', 'IP'], os.path.join(pasta_saida, 'conexoes.csv'))
                    salvar_csv(all_devices, ['Tipo', 'Id', 'Active', 'User'], os.path.join(pasta_saida, 'dispositivos.csv'))
                    salvar_csv(all_followers, ['Id', 'Username', 'Name', 'Data_Hora'], os.path.join(pasta_saida, 'seguidores.csv'))
                    salvar_csv(all_seguindo, ['Id', 'Username', 'Name', 'Simetria'], os.path.join(pasta_saida, 'seguindo.csv'))

                    # The 'conta.csv' should still only be written once with the first metadata found
                    if metadados_info and isinstance(metadados_info, dict):
                        df_conta = pd.DataFrame([metadados_info])
                        conta_csv = os.path.join(pasta_saida, 'conta.csv')
                        if not os.path.exists(conta_csv):
                            df_conta.to_csv(conta_csv, index=False, encoding='utf-8-sig')

                    print(f"[OK] Processamento finalizado para conta: {sanitize_filename(account_id)}")

            except Exception as e:
                print(f"[ERRO] Falha ao processar {zip_path}: {e}")
                traceback.print_exc()

def processar_todos():
    print("[INÍCIO] Processando arquivos ZIP...")
    processar_zips()
    print("[FIM] Processamento completo.")

if __name__ == '__main__':
    processar_todos()