# run_ui.py (Final Version with Cloned Output)
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import os
import sys
import queue
import re
import extratorv2testes # Your working main script

# --- Configuration ---
DATA_FOLDER = r"C:\CIAF\Extrator_Instagram\DADOS"

class QueueWriter:
    """A class to clone stdout to a queue for thread-safe UI updates."""
    def __init__(self, q):
        self.queue = q
        # --- FIX: Store the original stdout ---
        self.original_stdout = sys.stdout

    def write(self, text):
        # --- FIX: Write to both the original console and the UI queue ---
        self.original_stdout.write(text)
        self.queue.put(text)

    def flush(self):
        # This flush method is necessary to make stdout work correctly.
        self.original_stdout.flush()

class App:
    def __init__(self, root):
        self.root = root
        root.title("Extrator Instagram")
        root.geometry("550x170")
        root.resizable(False, False)

        main_frame = tk.Frame(root, padx=15, pady=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        self.status_label = tk.Label(main_frame, text="Pronto para iniciar.", font=("Segoe UI", 10), wraplength=520, justify=tk.LEFT)
        self.status_label.pack(anchor='w', pady=5)

        self.progress_bar = ttk.Progressbar(main_frame, mode='indeterminate', length=350)
        self.progress_bar.pack(pady=10, fill=tk.X, expand=True)
        
        self.start_button = tk.Button(main_frame, text="Iniciar Extração", command=self.start_extraction_thread, width=20, height=2)
        self.start_button.pack(pady=10)
        
        self.log_queue = queue.Queue()
        self.process_queue()

    def process_queue(self):
        """Checks the queue for messages from the extractor and updates the UI."""
        try:
            while True:
                message = self.log_queue.get_nowait()
                if message is None:
                    self.on_extraction_complete()
                    return
                clean_message = re.sub(r'\[.*?\]\s*', '', message).strip()
                if clean_message:
                    self.status_label.config(text=clean_message)
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.process_queue)

    def run_extraction_task(self):
        """
        This function runs in the background. It redirects stdout and then
        calls your main script's function.
        """
        writer = QueueWriter(self.log_queue)
        original_stdout = sys.stdout
        sys.stdout = writer
        
        try:
            extratorv2testes.processar_todos()
        except Exception as e:
            self.log_queue.put(f"ERRO: {e}")
        finally:
            sys.stdout = original_stdout
            self.log_queue.put(None)

    def on_extraction_complete(self):
        self.progress_bar.stop()
        self.status_label.config(text="Processamento concluído!")
        self.start_button.config(state=tk.NORMAL)
        if messagebox.askyesno("Sucesso", "Extração finalizada. Deseja abrir a pasta de dados?"):
            os.startfile(DATA_FOLDER)

    def start_extraction_thread(self):
        self.start_button.config(state=tk.DISABLED)
        self.status_label.config(text="Iniciando...")
        self.progress_bar.start(10)
        
        thread = threading.Thread(target=self.run_extraction_task)
        thread.daemon = True
        thread.start()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()