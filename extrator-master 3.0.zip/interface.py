import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox 
import excel
from main import *
import os


class App:
    def __init__(self, janela) -> None:
        self.janela = janela
        self.janela.title("Extrator Instagram")

        self.file_path = tk.StringVar()

        self.label_instrucao = tk.Label(janela, text="Selecione o arquivo \"records.html\".")
        self.label_instrucao.grid(row=0, column=0, columnspan=1, padx=10, pady=(10, 0), sticky='w')

        self.entrada_caminho = tk.Entry(janela, textvariable=self.file_path, width=50)
        self.entrada_caminho.grid(row=1, column=0, padx=10, pady=10)

        self.botao_selecionar = tk.Button(janela, text="Selecionar", command=self.selecionar_arquivo)
        self.botao_selecionar.grid(row=1, column=1, padx=10, pady=10)

        self.botao_extrair = tk.Button(janela, text="Extrair", command=self.iniciar_extracao)
        self.botao_extrair.grid(row=3, column=0, columnspan=2, padx=15, pady=15)

        self.label_status = tk.Label(janela, text="")
        self.label_status.grid(row=2, column=0, columnspan=2, padx=10, pady=10)
        

    def selecionar_arquivo(self) -> None:
        origem = filedialog.askopenfilename(filetypes=[('Arquivos HTML', '*.html')])

        if origem:
            self.file_path.set(origem)
      

    def obter_dados(self, origem):
        try:
            #conteudo = ler(origem)
            conteudo = limpar_texto(ler_arquivo(origem))
            dados_chats, dados_logs, dados_devices, dados_cadastro, dados_seguidores, dados_seguindo = extrair_tudo(conteudo)  
            return dados_chats, dados_logs, dados_devices, dados_cadastro, dados_seguidores, dados_seguindo
        except Exception as e:
            messagebox.showinfo("Erro", f"Erro na extração: {e}")
            return None, None, None

    def iniciar_extracao(self) -> None:
        self.label_status.config(text="Extraindo dados...")
        self.janela.update_idletasks()

        origem = self.entrada_caminho.get()


        if not origem:
            messagebox.showinfo("Erro", "Selecione um arquivo primeiro.")
            return

        try:
            dados_chats, dados_logs, dados_devices, dados_cadastro, dados_seguidores, dados_seguindo = self.obter_dados(origem)
            if dados_chats is not None:
                try:
                    excel.criar_planilha(dados_chats, dados_logs, dados_seguidores, dados_seguindo, dados_devices, dados_cadastro, origem)
                    self.label_status.config(text="Extração concluída!")
                    messagebox.showinfo("Info", f"EXTRAÇÃO CONCLUÍDA COM SUCESSO! \n\n\nATENÇÃO: A planilha gerada precisa ser mantida no mesmo diretório que a pasta \"linked_media\" para que os links funcionem.")
                except PermissionError:
                    messagebox.showerror("Erro de Permissão", "Feche o arquivo do excel e tente novamente.")    
                    
                
                # Adicionar botão para abrir a pasta do arquivo gerado
                self.botao_abrir_pasta = tk.Button(self.janela, text="Abrir Pasta", command=lambda: os.startfile(os.path.dirname(origem)))
                self.botao_abrir_pasta.grid(row=4, column=0, columnspan=2, padx=15, pady=15)
                
            else:
                self.label_status.config(text="Erro na extração.")
        except Exception as e:
            messagebox.showinfo("Erro", f"Erro na escrita no Excel: {e}")
            
            
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()