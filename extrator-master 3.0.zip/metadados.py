from util import *
import re

# FUNÇÃO PRINCIPAL: extrai os dados de cadastro a partir de uma região específica do HTML
def extrair_cadastro(conteudo: str) -> dict:
    inicio = ">Service<"
    fim = ">Ip Addresses Definition<"
    regiao_dados = obter_regiao_interesse(conteudo, inicio, fim)
    cadastro = obter_cadastro(regiao_dados)
    return cadastro

# FUNÇÃO AUXILIAR QUE LOCALIZA UM CAMPO ESPECÍFICO E LIMPA TAGS HTML
def localizar_campo_metadados(texto: str, inicio: str) -> str:
    if inicio not in texto:
        return ""
    try:
        saida = texto[texto.find(inicio) + len(inicio) - 1:texto.find("</div>", texto.find(inicio) + len(inicio))]
        saida = re.sub(r'<[\w\d ="\'.\/-]+>', '', saida).strip()
        return saida
    except:
        return ""

# FUNÇÃO AUXILIAR QUE EXTRAI OS CAMPOS PRINCIPAIS DO CADASTRO
def obter_cadastro(dados: str) -> dict:
    padroes = [
        ">Internal Ticket Number<",
        ">Target<",
        ">First<",
        ">Vanity Name<",
        ">Account Identifier<",
        ">Account Type<",
        ">Generated<",
        ">Date Range<",
        ">Registered Email Addresses<",
        ">Registration Date<",
        ">Registration Ip<",
        ">Phone Numbers<"
    ]

    # Correspondência com os nomes dos campos de saída no dicionário final
    campos = [
        "internal_ticket_number",
        "target",
        "nome",
        "username",
        "account_id",
        "account_type",
        "generated",
        "date_range",
        "mail_addresses",
        "registration_date",
        "registration_ip",
        "phone_numbers"
    ]

    # Executa a localização e extração dos valores
    valores = [localizar_campo_metadados(dados, padrao) for padrao in padroes]

    # Monta o dicionário com os resultados, aplicando fallback para campos vazios
    dicionario_cadastro = {
        campo: valor if valor else "Não Informado"
        for campo, valor in zip(campos, valores)
    }

    return dicionario_cadastro
