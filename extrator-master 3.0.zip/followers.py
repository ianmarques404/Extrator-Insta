from util import *

def extrair_seguidores(conteudo: str) -> list:
    lista_campos: list = obter_lista_campos(conteudo)
    inicio: str = ">Followers<"
    #fim: str = ">Photos Definition<"
    fim: str = ">" + str(lista_campos[lista_campos.index('followers') + 1]).replace("_",
                                                                                       " ").title() + " Definition<"
    seguidores_regiao: str = obter_regiao_interesse(conteudo, inicio, fim)
    posicoes: list = obter_posicoes(">Follower<", seguidores_regiao)
    tabela_seguidores: list = obter_texto_dados(seguidores_regiao, posicoes)
    seguidores: list = obter_seguidores(tabela_seguidores)
    return seguidores

# FUNÇÃO AUXILIAR QUE EXTRAI OS CAMPOS DO TEXTO PRINCIPAL
def obter_seguidores(dados: list) -> list:
    linhas_seguidores: list = []
    for dado in dados:
        seguidor: str = dado[dado.find('>Follower<')+9:dado.find("</div>",dado.find(">Follower<"))]
        seguidor = re.sub('<[\w \d\=\"\'\/]{1,}>','',seguidor)  
        try:
            username_seguidor = seguidor.split(" ")[0] if seguidor is not None else ""
        except:
            username_seguidor = ""
        try:
            id_seguidor = seguidor.split(" ")[1].strip("()") if seguidor is not None else ""
        except:
            id_seguidor = ""
        try:
            nome_seguidor = seguidor[seguidor.find("["):-1].strip("[]") if seguidor is not None else ""
        except:
            nome_seguidor = ""
        try:
            data_hora: str = dado[dado.find(">Timestamp<")+10:dado.find("</div>",dado.find(">Timestamp<"))]
            data_hora = re.sub('<[\w \d\=\"\'\/]{1,}>', '', data_hora)
        except:
            data_hora = ""
        try:
            data_hora_tratada: datetime = tratar_data_hora(data_hora) if data_hora is not None else ""
        except:
            data_hora_tratada = ""
        linhas_seguidores.append([id_seguidor,username_seguidor,nome_seguidor, data_hora_tratada])
    return linhas_seguidores


# FUNÇÕES PARA TESTE
def main(caminho):
    conteudo = ler_arquivo(caminho)
    conteudo = limpar_texto(conteudo)
    seguidores = extrair_seguidores(conteudo)
    for seguidor in seguidores[0:100]:
        print(seguidor)


if __name__ == '__main__':
    caminho: str = r"C:\Users\talles.tov\Downloads\4205.html"
    main(caminho)