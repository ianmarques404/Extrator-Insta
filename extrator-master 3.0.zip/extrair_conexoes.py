# extrair_conexoes.py (Optimized Anti-Freeze Version)
import re
from util import tratar_data_hora

def extrair_dados(conteudo: str) -> list:
    """
    Extracts IP connection data efficiently using an iterator to prevent
    freezes on large files.
    """
    print("Extraindo logs de conexão (método otimizado)...")
    dados = []
    
    # This pattern is more robust. It finds a timestamp and then looks for the
    # *next* IP address that appears, treating them as a single record.
    # The '.*?' is a non-greedy match that makes it very efficient.
    pattern = re.compile(
        r'(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})\s*UTC.*?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    )

    # Use re.finditer for memory efficiency. It processes one match at a time
    # instead of loading the entire file's content into memory.
    matches = pattern.finditer(conteudo)

    for match in matches:
        try:
            data_hora_str = match.group(1)
            ip = match.group(2)
            
            data_hora_tratada = tratar_data_hora(data_hora_str)
            fuso = "UTC" # All timestamps are UTC in this section
            
            dados.append([data_hora_tratada, fuso, ip])
        except IndexError:
            # Skip any malformed matches that might not have both groups
            continue

    print(f"Processamento de logs finalizado. {len(dados)} registros encontrados.")
    return dados