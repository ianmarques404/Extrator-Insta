from datetime import datetime
import re


def ler_arquivo(caminho: str) -> str:
    with open(caminho, 'r', encoding='utf-8') as arquivo:
        conteudo: str = arquivo.read()
        # print("Arquivo aberto.")
        # arquivo.close()
        # print("Arquivo fechado")
        return conteudo


def escrever_em_arquivo(nome_arquivo: str, conteudo: list):
    with open(nome_arquivo, 'w', encoding='utf-8') as arquivo:
        for linha in conteudo:
            arquivo.write(str(linha) + '\n')


def limpar_texto(texto: str) -> str:
    padroes = [
        r'(?:</div>)+<div id="page_\d{1,10}" class="pageBreak">Meta Platforms Business Record Page \d{1,10}',
        r'<div id="page_\d+" class="pageBreak">Meta Platforms Business Record Page \d+</div>',
        r'</div><div class="content-pane">(?:<div class="t o"><div class="t i"><div class="m"><div class="">)',
        r'</div><div class="content-pane h">',
        r'(?:<div class="t o"><div class="t i"><div class="m"><div class="">)',
        r'\\\\n',
        r'\n'
    ]

    for padrao in padroes:
        texto: str = re.sub(padrao,'',texto)

    return texto



def obter_regiao_interesse(texto: str, inicio_txt: str, fim_txt: str) -> str:
    inicio_pos = texto.find(inicio_txt)
    fim_pos = texto.find(fim_txt)
    texto = texto[inicio_pos:fim_pos]
    return texto


def obter_posicoes(padrao: str, texto: str) -> list:
    posicoes = []
    posicao = texto.find(padrao)
    # Buscando todas as ocorrências e criando uma lista de posições
    while posicao != -1:
        posicoes.append(posicao)
        posicao = texto.find(padrao, posicao + 1)
    return posicoes


def obter_texto_dados(texto: str, posicoes: list) -> list:
    # Função que extrai só a 'tabela'(a parte dos dados).

    # Criando a lista de mensagens
    dados: list = []
    for i in range(len(posicoes)-1):
        dados.append(texto[posicoes[i]:posicoes[i+1]])
    dados.append(texto[posicoes[-1]:])
    return dados


def tratar_data_hora(data_hora: str) -> datetime:
    ano = data_hora[0:4]
    mes = data_hora[5:7]
    dia = data_hora[8:10]
    hora = data_hora[11:19]
    formato_saida = "%d/%m/%Y %H:%M:%S"
    data_hora_saida = datetime.strptime(f"{dia}/{mes}/{ano} {hora}", formato_saida)
    return data_hora_saida

def localizar_campo(texto: str, inicio: str) -> str:
    saida = texto[texto.find(inicio)+len(inicio):texto.find("\n", texto.find(inicio)+len(inicio))]
    return saida

def obter_lista_campos(conteudo: str) -> list:
    inicio: str = ">Categories<"
    fim: str = ">Print Options<"
    texto: str = obter_regiao_interesse(conteudo, inicio, fim)
    lista: list = re.findall(r'property="(.*?)"', texto)
    return lista

